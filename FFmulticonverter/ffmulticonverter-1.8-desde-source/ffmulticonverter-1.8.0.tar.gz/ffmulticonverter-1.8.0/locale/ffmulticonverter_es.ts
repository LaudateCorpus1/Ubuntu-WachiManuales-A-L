<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.0">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="40"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="53"/>
        <source>About FF Multi Converter</source>
        <translation>Acerca de FF Multi Converter</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="39"/>
        <source>C&amp;redits</source>
        <translation>C&amp;réditos</translation>
    </message>
</context>
<context>
    <name>AddorEditPreset</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="386"/>
        <source>Preset name (one word, A-z, 0-9)</source>
        <translation>Nombre del preset (una palabra, A-z, 0-9)</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="388"/>
        <source>Preset label</source>
        <translation>Etiqueta del preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="390"/>
        <source>Preset command line parameters</source>
        <translation>Parámetros del preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="392"/>
        <source>Output file extension</source>
        <translation>Extensión del archivo de salida</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="418"/>
        <source>Add preset</source>
        <translation>Añadir preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="439"/>
        <source>Preset name can&apos;t be left blank.</source>
        <translation>El nombre del preset no puede quedar en blanco</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="458"/>
        <source>Preset label can&apos;t be left blank.</source>
        <translation>La etiqueta del preset no puede quedar en blanco</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="465"/>
        <source>Command label can&apos;t be left blank.</source>
        <translation>La etiqueta de comando no puede quedar en blanco</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="472"/>
        <source>Extension label can&apos;t be left blank.</source>
        <translation>La etiqueta de extensión no puede quedar en blanco</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="416"/>
        <source>Edit {0}</source>
        <translation>Editar {0}</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Extension must be one word and must not start with a  dot.</source>
        <translation>La extensión debe ser una sola palabra y no puede comenzar por un punto.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="447"/>
        <source>Preset name must be one word, start with a letter and contain only letters, digits, underscores, hyphens, colons and periods. It cannot also start with xml.</source>
        <translation>El nombre del preajuste debe ser una sola palabra, comenzar por una letra y contener sólo letras, dígitos, guiones, guiones bajos, dos puntos y puntos. Tampoco debe comenzar con XML.</translation>
    </message>
</context>
<context>
    <name>AudioVideoTab</name>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="62"/>
        <source>Convert to:</source>
        <translation>Convertir a:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="76"/>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="78"/>
        <source>Preset</source>
        <translation>Preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="37"/>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="84"/>
        <source>Video Size:</source>
        <translation>Tamaño del vídeo:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="85"/>
        <source>Aspect:</source>
        <translation>Aspecto:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="86"/>
        <source>Frame Rate (fps):</source>
        <translation>Frame Rate (fps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="87"/>
        <source>Video Bitrate (kbps):</source>
        <translation>Bitrate de Video (kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="125"/>
        <source>Frequency (Hz):</source>
        <translation>Frecuencia (Hz):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="127"/>
        <source>Audio Bitrate (kbps):</source>
        <translation>Bitrate de audio (kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="280"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="110"/>
        <source>Preserve aspect ratio</source>
        <translation>Preservar la relación de aspecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="111"/>
        <source>Preserve video size</source>
        <translation>Preservar el tamaño del vídeo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="126"/>
        <source>Audio Channels:</source>
        <translation>Canales de audio</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="158"/>
        <source>Split file. Begin time</source>
        <translation>Dividir el fichero. Momento de inicio</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="160"/>
        <source>Duration</source>
        <translation>Duración</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="166"/>
        <source>Embed subtitle:</source>
        <translation>Incrustar subtítulos:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="171"/>
        <source>Rotate:</source>
        <translation>Girar:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="286"/>
        <source>Choose File</source>
        <translation>Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="45"/>
        <source>None</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="47"/>
        <source>clockwise</source>
        <translation>en sentido horario</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="53"/>
        <source>vertical flip</source>
        <translation>inversión vertical</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="49"/>
        <source>counter clockwise</source>
        <translation>en sentido antihorario</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="52"/>
        <source>horizontal flip</source>
        <translation>inversión horizontal</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="128"/>
        <source>Threads:</source>
        <translation>Hilos:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="38"/>
        <source>Disable</source>
        <translation>Desactivar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="280"/>
        <source>FFmpeg is not installed!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CreditsDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="71"/>
        <source>Written by</source>
        <translation>Escrito por</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="72"/>
        <source>Translated by</source>
        <translation>Traducido por</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="83"/>
        <source>Credits</source>
        <translation>Créditos</translation>
    </message>
</context>
<context>
    <name>DocumentTab</name>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="52"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="33"/>
        <source>Convert to:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="52"/>
        <source>Unocov is not installed!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="37"/>
        <source>Convert to:</source>
        <translation>Convertir a:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="45"/>
        <source>Image Size:</source>
        <translation>Tamaño de la Imagen:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="109"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="109"/>
        <source>The size LineEdit may not be empty.</source>
        <translation>El valor de LineEdit no puede estar vacío.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="56"/>
        <source>Maintain aspect ratio</source>
        <translation>Mantener la proporción de aspecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="39"/>
        <source>Extra options:</source>
        <translation>Opciones extra:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="57"/>
        <source>Auto-crop</source>
        <translation>Recorte automático</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="61"/>
        <source>Rotate</source>
        <translation>Girar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="61"/>
        <source>degrees - clockwise</source>
        <translation>grados en sentido horario</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="65"/>
        <source>Vertical flip</source>
        <translation>Inversión vertical</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="66"/>
        <source>Horizontal flip</source>
        <translation>Inversión horizontal</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="105"/>
        <source>ImageMagick is not installed!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="69"/>
        <source>Output folder:</source>
        <translation>Carpeta de salida:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="81"/>
        <source>Audio/Video</source>
        <translation>Audio/Video</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="81"/>
        <source>Images</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="82"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="91"/>
        <source>Delete original</source>
        <translation>Borrar el original</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="92"/>
        <source>&amp;Convert</source>
        <translation>&amp;Convertir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="106"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="106"/>
        <source>Open a file</source>
        <translation>Abrir un archivo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="110"/>
        <source>Convert</source>
        <translation>Convertir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="110"/>
        <source>Convert files</source>
        <translation>Convertir archivos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="114"/>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="118"/>
        <source>Edit Presets</source>
        <translation>Editar Presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="122"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="122"/>
        <source>Import presets</source>
        <translation>Importar presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="126"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="126"/>
        <source>Export presets</source>
        <translation>Exportar presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="130"/>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="130"/>
        <source>Reset presets</source>
        <translation>Restablecer presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="62"/>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="142"/>
        <source>Clear form</source>
        <translation>Limpiar el formulario</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="146"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="170"/>
        <source>About</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="175"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="176"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="177"/>
        <source>Presets</source>
        <translation>Presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="178"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="298"/>
        <source>Choose File</source>
        <translation>Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="337"/>
        <source>Choose output destination</source>
        <translation>Seleccionar destino de salida</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="375"/>
        <source>You must choose an output folder!</source>
        <translation>Debes elegir una carpeta de salida!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="379"/>
        <source>Output folder does not exists!</source>
        <translation>La carpeta de salida no existe!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="385"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="251"/>
        <source>Missing dependencies:</source>
        <translation>Dependencias no encontradas:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="60"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="61"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="142"/>
        <source>Clear All</source>
        <translation>Limpiar todo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="372"/>
        <source>You must add at least one file to convert!</source>
        <translation>Debes añadir, por lo menos, un archivo para convertir!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="89"/>
        <source>Save each file in the same
folder as input file</source>
        <translation>Grabar cada archivo en la misma
carpeta que el original</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="134"/>
        <source>Synchronize</source>
        <translation>Sincronizar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="134"/>
        <source>Synchronize presets</source>
        <translation>Sincronizar presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="138"/>
        <source>Remove old</source>
        <translation>Quitar todos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="138"/>
        <source>Remove old presets</source>
        <translation>Quitar presets antiguos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="165"/>
        <source>documentation</source>
        <translation>documentación</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="427"/>
        <source>Convert among several file types to other formats</source>
        <translation>Convertir muchos tipos de archivos a otros formatos</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="35"/>
        <source>Save files</source>
        <translation>Grabar Archivos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="36"/>
        <source>Existing files:</source>
        <translation>Archivos existentes:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="37"/>
        <source>Add &apos;~&apos; prefix</source>
        <translation>Añadir Prefijo &apos;~&apos;</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="38"/>
        <source>Overwrite</source>
        <translation>Sobreescribir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="42"/>
        <source>Default output destination:</source>
        <translation>Destino de salida por defecto:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="48"/>
        <source>Name files</source>
        <translation>Nombrar archivos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="49"/>
        <source>Prefix:</source>
        <translation>Prefijo:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="50"/>
        <source>Suffix:</source>
        <translation>Sufijo:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="69"/>
        <source>Default command:</source>
        <translation>Comando por defecto:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="136"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="137"/>
        <source>Audio/Video</source>
        <translation>Audio/Video</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="156"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="207"/>
        <source>Choose default output destination</source>
        <translation>Selecciona el destino de salida por defecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="72"/>
        <source>Video codecs</source>
        <translation>Códecs de vídeo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="75"/>
        <source>Audio codecs</source>
        <translation>Códecs de audio</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="117"/>
        <source>Extra formats</source>
        <translation>Formatos extra</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="88"/>
        <source>Default video codecs</source>
        <translation>Códecs de vídeo por defecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="89"/>
        <source>Default audio codecs</source>
        <translation>Códecs de audio por defecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="101"/>
        <source>Default options:</source>
        <translation>Opciones por defecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="138"/>
        <source>Images</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="66"/>
        <source>Path to executable:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="139"/>
        <source>Documents</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Progress</name>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="69"/>
        <source>In progress: </source>
        <translation>En progreso:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="73"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="75"/>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="106"/>
        <source>Conversion</source>
        <translation>Conversión</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="196"/>
        <source>Cancel Conversion</source>
        <translation>Cancelar la conversión</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="196"/>
        <source>Are you sure you want to cancel conversion?</source>
        <translation>Estás seguro de que quieres cancelar la conversión?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="230"/>
        <source>In progress:</source>
        <translation>En progreso:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="159"/>
        <source>Report</source>
        <translation>Informe</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="164"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="160"/>
        <source>Converted: {0}/{1}</source>
        <translation>Convertidos: {0}/{1}</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="72"/>
        <source>Shutdown after conversion</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShowPresets</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="43"/>
        <source>Preset label</source>
        <translation>Etiqueta del preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="46"/>
        <source>Preset command line parameters</source>
        <translation>Parámetros del preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="49"/>
        <source>Output file extension</source>
        <translation>Extensión del archivo de salida</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="52"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="53"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="54"/>
        <source>Delete all</source>
        <translation>Borrar todo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="55"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="58"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="95"/>
        <source>Edit Presets</source>
        <translation>Editar presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="281"/>
        <source>Delete Preset</source>
        <translation>Borrar Preset</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="192"/>
        <source>Are you sure that you want to delete all presets?</source>
        <translation>Estás seguro de que quieres borrar todos los presets?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="249"/>
        <source>All current presets will be deleted.
Are you sure that you want to continue?</source>
        <translation>Todos los presets serán borrados.⏎
Estás seguro de que quieres continuar?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="281"/>
        <source>Are you sure that you want to restore the default presets?</source>
        <translation>Estás seguro de que quieres restaurar los presets por defecto?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="259"/>
        <source>Import failed!</source>
        <translation>Importación fallida!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="56"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="301"/>
        <source>Presets Synchronization</source>
        <translation>Sincronización de presets</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="301"/>
        <source>Current presets and default presets will be merged. Are you sure that you want to continue?</source>
        <translation>Todos los presets serán borrados.⏎
Estás seguro de que quieres continuar?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="350"/>
        <source>Remove old presets</source>
        <translation>Quitar presets antiguos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="178"/>
        <source>Are you sure that you want to delete the {0} preset?</source>
        <translation>¿Seguro que quiere borrar el preajuste {0}?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="267"/>
        <source>Export presets</source>
        <translation>Exportar los preajustes</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="350"/>
        <source>All presets with an __OLD suffix will be deleted. Are you sure that you want to continue?</source>
        <translation>Se borrarán todos los preajustes con un sufijo __OLD. ¿Seguro que quiere continuar?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="255"/>
        <source>Successful import!</source>
        <translation>¡Importación correcta!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Default presets restored successfully.</source>
        <translation>Los preajustes por defecto se han restaurado correctamente.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="344"/>
        <source>Synchronization completed.
Your presets are up to date!</source>
        <translation>Sincronización completado.
¡Los preajustes se han actualizado!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="365"/>
        <source>Old presets successfully removed.</source>
        <translation>Los preajustes obsoletos se han eliminado correctamente.</translation>
    </message>
</context>
<context>
    <name>Tab</name>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="186"/>
        <source>More</source>
        <translation>Más</translation>
    </message>
</context>
</TS>