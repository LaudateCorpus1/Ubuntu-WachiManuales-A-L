<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="vi" sourcelanguage="">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="40"/>
        <source>&amp;Close</source>
        <translation>&amp;Đóng lại</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="53"/>
        <source>About FF Multi Converter</source>
        <translation>Thông tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="39"/>
        <source>C&amp;redits</source>
        <translation>Đ&amp;óng góp</translation>
    </message>
</context>
<context>
    <name>AddorEditPreset</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="386"/>
        <source>Preset name (one word, A-z, 0-9)</source>
        <translation>Tên điều khiển (một từ, A-z, 0-9)</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="388"/>
        <source>Preset label</source>
        <translation>Nhãn điều khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="390"/>
        <source>Preset command line parameters</source>
        <translation>Tham số dòng lệnh điều khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="392"/>
        <source>Output file extension</source>
        <translation>Định dạng tập tin xuất ra</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="403"/>
        <source>Edit %1</source>
        <translation type="obsolete">Chỉnh sửa %1</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="418"/>
        <source>Add preset</source>
        <translation>Thêm điều khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Error!</source>
        <translation>Xảy ra lỗi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="439"/>
        <source>Preset name can&apos;t be left blank.</source>
        <translation>Tên điều khiển không được để trống.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="434"/>
        <source>Preset name must be one word and contain only letters and digits.</source>
        <translation type="obsolete">Tên điều khiển phải là một từ và chỉ chứa các ký tự chữ cái latinh và ký số.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="458"/>
        <source>Preset label can&apos;t be left blank.</source>
        <translation>Nhãn của điều khiển không được để trống.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="465"/>
        <source>Command label can&apos;t be left blank.</source>
        <translation>Nhãn của dòng lệnh không được để trống.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="472"/>
        <source>Extension label can&apos;t be left blank.</source>
        <translation>Nhãn của định dạng tập tin không thể được để trống.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="453"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">Định dạng tập tin phải là một từ và không phải bắt đầu với một dấu chấm.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="416"/>
        <source>Edit {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Extension must be one word and must not start with a  dot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="447"/>
        <source>Preset name must be one word, start with a letter and contain only letters, digits, underscores, hyphens, colons and periods. It cannot also start with xml.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioVideoTab</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="598"/>
        <source>No Change</source>
        <translation type="obsolete">Không có thay đổi nào</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="62"/>
        <source>Convert to:</source>
        <translation>Chuyển đổi sang:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="607"/>
        <source>Other</source>
        <translation type="obsolete">Các phần khác</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="76"/>
        <source>Command:</source>
        <translation>Dòng lệnh:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="78"/>
        <source>Preset</source>
        <translation>Điều khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="37"/>
        <source>Default</source>
        <translation>Mặc định</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="84"/>
        <source>Video Size:</source>
        <translation>Kích thước Video:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="85"/>
        <source>Aspect:</source>
        <translation>Khía cạnh:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="86"/>
        <source>Frame Rate (fps):</source>
        <translation>Tỷ lệ khung hình (khung hình giây):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="87"/>
        <source>Video Bitrate (kbps):</source>
        <translation>Tần số hình ảnh (kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="125"/>
        <source>Frequency (Hz):</source>
        <translation>Tần số (Hz):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="656"/>
        <source>Channels:</source>
        <translation type="obsolete">Kênh:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="127"/>
        <source>Audio Bitrate (kbps):</source>
        <translation>Tần số âm thanh (kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="280"/>
        <source>Error!</source>
        <translation>Xảy ra lỗi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="299"/>
        <source>Neither ffmpeg nor avconv are installed.
You will not be able to convert audio/video files until you install one of them.</source>
        <translation type="obsolete">Cả phần ffmpeg hoặc avconv vẫn chưa được cài đặt.
Bạn sẽ không thể chuyển đổi các tập tin âm thanh/hình ảnh cho đến khi bạn cài đặt các phầ này.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="778"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">Định dạng tập tin phải là một từ và không được bắt đầu với một dấu chấm.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="785"/>
        <source>The command LineEdit may not be empty.</source>
        <translation type="obsolete">Dòng lệnh LineEdit không được để trống.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="110"/>
        <source>Preserve aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="111"/>
        <source>Preserve video size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="126"/>
        <source>Audio Channels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="158"/>
        <source>Split file. Begin time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="160"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="166"/>
        <source>Embed subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="171"/>
        <source>Rotate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="286"/>
        <source>Choose File</source>
        <translation type="unfinished">Chọn tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="45"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="47"/>
        <source>clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="53"/>
        <source>vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="49"/>
        <source>counter clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="52"/>
        <source>horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="128"/>
        <source>Threads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="38"/>
        <source>Disable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="280"/>
        <source>FFmpeg is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreditsDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="71"/>
        <source>Written by</source>
        <translation>Tác giả</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="72"/>
        <source>Translated by</source>
        <translation>Dịch giả</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Đóng lại</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="83"/>
        <source>Credits</source>
        <translation>Đóng góp</translation>
    </message>
</context>
<context>
    <name>DocumentTab</name>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="41"/>
        <source>Convert:</source>
        <translation type="obsolete">Chuyển đổi:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="62"/>
        <source>Unocov is not installed.
You will not be able to convert document files until you install it.</source>
        <translation type="obsolete">Unocov vẫn chưa được cài đặt.
Bạn sẽ không thể chuyển đổi được các tập tin tài liệu cho đến khi bạn cài đặt phần này.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="52"/>
        <source>Error!</source>
        <translation>Xảy ra lỗi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="1022"/>
        <source>%1 is not %2!</source>
        <translation type="obsolete">%1 không phải là %2!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="85"/>
        <source>You can not make parallel document conversions.</source>
        <translation type="obsolete">Bạn không được thực hiện nhiều chuyển đổi tài liệu song song cùng lúc.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="991"/>
        <source>%1 to %2</source>
        <translation type="obsolete">%1 sang %2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="33"/>
        <source>Convert to:</source>
        <translation type="unfinished">Chuyển đổi sang:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="52"/>
        <source>Unocov is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="37"/>
        <source>Convert to:</source>
        <translation>Chuyển đổi sang:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="45"/>
        <source>Image Size:</source>
        <translation>Kích thước ảnh:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="109"/>
        <source>Error!</source>
        <translation>Xảy ra lỗi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="953"/>
        <source>PythonMagick is not installed.
You will not be able to convert image files until you install it.</source>
        <translation type="obsolete">PythonMagick vẫn chưa được cài đặt.
Bạn sẽ không thể chuyển đổi các tập tin hình ảnh cho đến khi bạn cài đặt phần này.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="109"/>
        <source>The size LineEdit may not be empty.</source>
        <translation>Kích thước LineEdit không được để trống.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="56"/>
        <source>Maintain aspect ratio</source>
        <translation>Duy trì tỉ lệ khung hình</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="39"/>
        <source>Extra options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="57"/>
        <source>Auto-crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="61"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="61"/>
        <source>degrees - clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="65"/>
        <source>Vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="66"/>
        <source>Horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="105"/>
        <source>ImageMagick is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="69"/>
        <source>Output folder:</source>
        <translation>Thư mục xuất ra:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="81"/>
        <source>Audio/Video</source>
        <translation>Âm thanh/phim ảnh</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="81"/>
        <source>Images</source>
        <translation>Hình ảnh</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="82"/>
        <source>Documents</source>
        <translation>Tài liệu</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="91"/>
        <source>Delete original</source>
        <translation>Xóa bản gốc</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="92"/>
        <source>&amp;Convert</source>
        <translation>&amp;Chuyển đổi</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="106"/>
        <source>Open</source>
        <translation>Mở</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="106"/>
        <source>Open a file</source>
        <translation>Mở tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="110"/>
        <source>Convert</source>
        <translation>Chuyển đổi</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="110"/>
        <source>Convert files</source>
        <translation>Chuyển đổi tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="114"/>
        <source>Quit</source>
        <translation>Thoát</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="118"/>
        <source>Edit Presets</source>
        <translation>Chỉnh sửa Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="122"/>
        <source>Import</source>
        <translation>Nhập dữ liệu</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="122"/>
        <source>Import presets</source>
        <translation>Nhập dữ liệu Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="126"/>
        <source>Export</source>
        <translation>Xuất dữ liệu</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="126"/>
        <source>Export presets</source>
        <translation>Xuất dữ liệu Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="130"/>
        <source>Reset</source>
        <translation>Cài đặt lại</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="130"/>
        <source>Reset presets</source>
        <translation>Cài đặt lại phần Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="62"/>
        <source>Clear</source>
        <translation>Xóa nội dung</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="142"/>
        <source>Clear form</source>
        <translation>Mẫu đơn xóa nội dung</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="146"/>
        <source>Preferences</source>
        <translation>Tùy Biến</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="170"/>
        <source>About</source>
        <translation>Dịch bởi Vietnamesel10n</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="175"/>
        <source>File</source>
        <translation>Tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="176"/>
        <source>Edit</source>
        <translation>Chỉnh sửa</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="177"/>
        <source>Presets</source>
        <translation>Định sẵn</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="178"/>
        <source>Help</source>
        <translation>Trợ giúp</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>All Files</source>
        <translation type="obsolete">Tất cả tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>Audio/Video Files</source>
        <translation type="obsolete">Tập tin âm thanh/phim ảnh</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Image Files</source>
        <translation type="obsolete">Tập tin hình ảnh</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Document Files</source>
        <translation type="obsolete">Tập tin tài liệu</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="298"/>
        <source>Choose File</source>
        <translation>Chọn tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="337"/>
        <source>Choose output destination</source>
        <translation>Chọn thư mục xuất dữ liệu</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="375"/>
        <source>You must choose an output folder!</source>
        <translation>Bạn phải chọn một thư mục xuất dữ liệu!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="379"/>
        <source>Output folder does not exists!</source>
        <translation>Thư mục xuất dữ liệu không tồn tại!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="385"/>
        <source>Error!</source>
        <translation>Xảy ra lỗi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="444"/>
        <source>Convert among several file types to other extensions</source>
        <translation type="obsolete">Chuyển đổi giữa các dạng tập tin sang các định dạng khác</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="251"/>
        <source>Missing dependencies:</source>
        <translation>Phần phụ thuộc còn thiếu:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="60"/>
        <source>Add</source>
        <translation>Thêm vào</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="61"/>
        <source>Delete</source>
        <translation>Xoá</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="142"/>
        <source>Clear All</source>
        <translation>Dọn sạch</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="372"/>
        <source>You must add at least one file to convert!</source>
        <translation>Bạn phải thêm ít nhất một tập tin để chuyển đổi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="89"/>
        <source>Save each file in the same
folder as input file</source>
        <translation>Lưu mỗi tập tin trong
cùng thư mục như tập tin nhập vào</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="134"/>
        <source>Synchronize</source>
        <translation>Đồng bộ hóa</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="134"/>
        <source>Synchronize presets</source>
        <translation>Đồng bộ hoá các Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="138"/>
        <source>Remove old</source>
        <translation>Loại bỏ các phần cũ</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="138"/>
        <source>Remove old presets</source>
        <translation>Loại bỏ các Điều Khiển cũ</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="165"/>
        <source>documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="427"/>
        <source>Convert among several file types to other formats</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="35"/>
        <source>Save files</source>
        <translation>Lưu lại các tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="36"/>
        <source>Existing files:</source>
        <translation>Các tập tin hiện có:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="37"/>
        <source>Add &apos;~&apos; prefix</source>
        <translation>Thêm vào phía trước &apos;~&apos;</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="38"/>
        <source>Overwrite</source>
        <translation>Viết đè lên</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="42"/>
        <source>Default output destination:</source>
        <translation>Thư mục xuất dữ liệu mặc định:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="48"/>
        <source>Name files</source>
        <translation>Đặt tên các tập tin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="49"/>
        <source>Prefix:</source>
        <translation>Phần đứng phía trước:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="50"/>
        <source>Suffix:</source>
        <translation>Phần đứng phía sau:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="73"/>
        <source>FFmpeg</source>
        <translation type="obsolete">FFmpeg</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="69"/>
        <source>Default command:</source>
        <translation>Lệnh mặc định:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="76"/>
        <source>Use:</source>
        <translation type="obsolete">Sử dụng:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="78"/>
        <source>avconv</source>
        <translation type="obsolete">avconv</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="136"/>
        <source>General</source>
        <translation>Tổng quan</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="137"/>
        <source>Audio/Video</source>
        <translation>Âm thanh/phim ảnh</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="156"/>
        <source>Preferences</source>
        <translation>Tùy biến</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="207"/>
        <source>Choose default output destination</source>
        <translation>Chọn thư mục xuất dữ liệu mặc định</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="72"/>
        <source>Video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="75"/>
        <source>Audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="117"/>
        <source>Extra formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="88"/>
        <source>Default video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="89"/>
        <source>Default audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="66"/>
        <source>Path to executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="101"/>
        <source>Default options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="138"/>
        <source>Images</source>
        <translation type="unfinished">Hình ảnh</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="139"/>
        <source>Documents</source>
        <translation type="unfinished">Tài liệu</translation>
    </message>
</context>
<context>
    <name>Progress</name>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="69"/>
        <source>In progress: </source>
        <translation>Đang tiến hành:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="71"/>
        <source>Total:</source>
        <translation type="obsolete">Tổng số :</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="73"/>
        <source>Cancel</source>
        <translation>Hủy bỏ</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="75"/>
        <source>Details</source>
        <translation>Chi tiết</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="106"/>
        <source>Conversion</source>
        <translation>Chuyển đổi</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="172"/>
        <source>Converted: %1/%2</source>
        <translation type="obsolete">Đã chuyể đổi: %1/%2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="196"/>
        <source>Cancel Conversion</source>
        <translation>Hủy bỏ tiến trình chuyển đổi</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="196"/>
        <source>Are you sure you want to cancel conversion?</source>
        <translation>Bạn có chắc muốn hủy bỏ quá trình chuyển đổi hay không?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="230"/>
        <source>In progress:</source>
        <translation>Đang tiến hành:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="159"/>
        <source>Report</source>
        <translation>Báo cáo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="164"/>
        <source>Close</source>
        <translation>Đóng lại</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="160"/>
        <source>Converted: {0}/{1}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="72"/>
        <source>Shutdown after conversion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShowPresets</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="43"/>
        <source>Preset label</source>
        <translation>Nhãn điều khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="46"/>
        <source>Preset command line parameters</source>
        <translation>Tham số dòng lệnh điều khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="49"/>
        <source>Output file extension</source>
        <translation>Định dạng tập tin xuất ra</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="52"/>
        <source>Add</source>
        <translation>Thêm</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="53"/>
        <source>Delete</source>
        <translation>Xoá</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="54"/>
        <source>Delete all</source>
        <translation>Xóa tất cả</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="55"/>
        <source>Edit</source>
        <translation>Chỉnh sửa&apos;</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="58"/>
        <source>OK</source>
        <translation>Đồng ý</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="95"/>
        <source>Edit Presets</source>
        <translation>Chỉnh sửa Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="281"/>
        <source>Delete Preset</source>
        <translation>Xoá Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="184"/>
        <source>Are you sure that you want to delete the %1 preset?</source>
        <translation type="obsolete">Bạn có chắc muốn xóa bảo phần điều khiển %1?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="192"/>
        <source>Are you sure that you want to delete all presets?</source>
        <translation>Bạn có chắc muốn xóa bỏ toàn bộ các điều khiển?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="249"/>
        <source>All current presets will be deleted.
Are you sure that you want to continue?</source>
        <translation>Tất cả các điều khiể hiện tại sẽ bị xóa.
Bạn có chắc muốn tiếp tục thao tác này không?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="281"/>
        <source>Are you sure that you want to restore the default presets?</source>
        <translation>Bạn có chắc muốn khôi phục lại các điều khiển về theo mặc định hay không?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="257"/>
        <source>Succesful import!</source>
        <translation type="obsolete">Đã nhập dữ liệu thành công!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="259"/>
        <source>Import failed!</source>
        <translation>Nhập dữ liệu gặp lỗi!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="56"/>
        <source>Search</source>
        <translation>Tìm Kiếm</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="301"/>
        <source>Presets Synchronization</source>
        <translation>Đồng Bộ Hóa Các Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="301"/>
        <source>Current presets and default presets will be merged. Are you sure that you want to continue?</source>
        <translation>Các điều khiển hiện tại và các điều khiển mặc định sẽ được ghép nối chung vào nhau. Bạn có muốn tiếp tục thao tác này hay không?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="350"/>
        <source>Remove old presets</source>
        <translation>Loại bỏ các điều khiển cũ</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="341"/>
        <source>All presets with an __OLD prefix will be deleted. Are you sure that you want to continue?</source>
        <translation type="obsolete">Tất cả các điều khiển có phần __OLD đứng phía trước tên sẽ bị xóa. Bạn có muốn tiếp tục thao tác này?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="178"/>
        <source>Are you sure that you want to delete the {0} preset?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="267"/>
        <source>Export presets</source>
        <translation type="unfinished">Xuất dữ liệu Điều Khiển</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="350"/>
        <source>All presets with an __OLD suffix will be deleted. Are you sure that you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="255"/>
        <source>Successful import!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Default presets restored successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="344"/>
        <source>Synchronization completed.
Your presets are up to date!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="365"/>
        <source>Old presets successfully removed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tab</name>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="186"/>
        <source>More</source>
        <translation>Thêm</translation>
    </message>
</context>
</TS>
