<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="gl" sourcelanguage="">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="40"/>
        <source>&amp;Close</source>
        <translation>&amp;Pechar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="53"/>
        <source>About FF Multi Converter</source>
        <translation>Sobre o FF Multi Converter</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="39"/>
        <source>C&amp;redits</source>
        <translation>C&amp;réditos</translation>
    </message>
</context>
<context>
    <name>AddorEditPreset</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="386"/>
        <source>Preset name (one word, A-z, 0-9)</source>
        <translation>Nome da predefinición (unha palabra, A-z, 0-9)</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="388"/>
        <source>Preset label</source>
        <translation>Etiqueta da predefinición</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="390"/>
        <source>Preset command line parameters</source>
        <translation>Parámetros da liña de ordes predefinidas</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="392"/>
        <source>Output file extension</source>
        <translation>Extensión do ficheiro de saída</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="403"/>
        <source>Edit %1</source>
        <translation type="obsolete">Editar %1</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="418"/>
        <source>Add preset</source>
        <translation>Engadir predefinición</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="439"/>
        <source>Preset name can&apos;t be left blank.</source>
        <translation>O nome da predefinición non pode quedar en branco.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="434"/>
        <source>Preset name must be one word and contain only letters and digits.</source>
        <translation type="obsolete">O nome da predefinición ten que ser unha palabra e só pode conter letras e números.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="458"/>
        <source>Preset label can&apos;t be left blank.</source>
        <translation>A etiqueta da predefinición non pode quedar en branco.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="465"/>
        <source>Command label can&apos;t be left blank.</source>
        <translation>A etiqueta da orde non pode quedar en branco.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="472"/>
        <source>Extension label can&apos;t be left blank.</source>
        <translation>A etiqueta da extensión non pode quedar en branco.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="453"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">A extensión ten que ser unha sola palabra e non pode comezar por un punto.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="416"/>
        <source>Edit {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Extension must be one word and must not start with a  dot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="447"/>
        <source>Preset name must be one word, start with a letter and contain only letters, digits, underscores, hyphens, colons and periods. It cannot also start with xml.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioVideoTab</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="598"/>
        <source>No Change</source>
        <translation type="obsolete">Sen cambios</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="62"/>
        <source>Convert to:</source>
        <translation>Converter a:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="607"/>
        <source>Other</source>
        <translation type="obsolete">Outro</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="76"/>
        <source>Command:</source>
        <translation>Orde:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="78"/>
        <source>Preset</source>
        <translation>Predefinición</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="37"/>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="84"/>
        <source>Video Size:</source>
        <translation>Tamaño do vídeo:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="85"/>
        <source>Aspect:</source>
        <translation>Aspecto:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="86"/>
        <source>Frame Rate (fps):</source>
        <translation>Taxa de fotogramas (fps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="87"/>
        <source>Video Bitrate (kbps):</source>
        <translation>Taxa de mostraxe do vídeo (kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="125"/>
        <source>Frequency (Hz):</source>
        <translation>Frecuencia (Hz):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="656"/>
        <source>Channels:</source>
        <translation type="obsolete">Canles:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="127"/>
        <source>Audio Bitrate (kbps):</source>
        <translation>Taxa de mostraxe do son (kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="280"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="299"/>
        <source>Neither ffmpeg nor avconv are installed.
You will not be able to convert audio/video files until you install one of them.</source>
        <translation type="obsolete">ffmpeg e avconv non están instalados.
Non é posíbel converter ficheiros de son/vídeo sen instalalos.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="778"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">A extensión ten que ser unha sola palabra e non pode comezar por un punto.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="785"/>
        <source>The command LineEdit may not be empty.</source>
        <translation type="obsolete">A orde LineEdit non pode quedar baleira.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="110"/>
        <source>Preserve aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="111"/>
        <source>Preserve video size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="126"/>
        <source>Audio Channels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="158"/>
        <source>Split file. Begin time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="160"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="166"/>
        <source>Embed subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="171"/>
        <source>Rotate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="286"/>
        <source>Choose File</source>
        <translation type="unfinished">Escoller o ficheiro</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="45"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="47"/>
        <source>clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="53"/>
        <source>vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="49"/>
        <source>counter clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="52"/>
        <source>horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="128"/>
        <source>Threads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="38"/>
        <source>Disable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="280"/>
        <source>FFmpeg is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreditsDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="71"/>
        <source>Written by</source>
        <translation>Escrito por</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="72"/>
        <source>Translated by</source>
        <translation>Traducido por</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Pechar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="83"/>
        <source>Credits</source>
        <translation>Créditos</translation>
    </message>
</context>
<context>
    <name>DocumentTab</name>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="41"/>
        <source>Convert:</source>
        <translation type="obsolete">Converter:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="62"/>
        <source>Unocov is not installed.
You will not be able to convert document files until you install it.</source>
        <translation type="obsolete">Unocov non está instalado.
Non é posíbel converter ficheiros de documentos sen instalalo.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="52"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="1022"/>
        <source>%1 is not %2!</source>
        <translation type="obsolete">%1 non é %2!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="85"/>
        <source>You can not make parallel document conversions.</source>
        <translation type="obsolete">Non é posíbel facer conversiones de documentos en paralelo.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="991"/>
        <source>%1 to %2</source>
        <translation type="obsolete">%1 a %2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="33"/>
        <source>Convert to:</source>
        <translation type="unfinished">Converter a:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="52"/>
        <source>Unocov is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="37"/>
        <source>Convert to:</source>
        <translation>Converter a:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="45"/>
        <source>Image Size:</source>
        <translation>Tamaño da imaxe:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="109"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="953"/>
        <source>PythonMagick is not installed.
You will not be able to convert image files until you install it.</source>
        <translation type="obsolete">PythonMagick non está instalado.
Non é posíbel converter ficheiros de imaxe sen instalalo.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="109"/>
        <source>The size LineEdit may not be empty.</source>
        <translation>O tamaño de LineEdit non pode estar baleiro.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="56"/>
        <source>Maintain aspect ratio</source>
        <translation>Manter a proporción do aspecto</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="39"/>
        <source>Extra options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="57"/>
        <source>Auto-crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="61"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="61"/>
        <source>degrees - clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="65"/>
        <source>Vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="66"/>
        <source>Horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="105"/>
        <source>ImageMagick is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="69"/>
        <source>Output folder:</source>
        <translation>Cartafol de saída:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="81"/>
        <source>Audio/Video</source>
        <translation>Son/Vídeo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="81"/>
        <source>Images</source>
        <translation>Imaxes</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="82"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="91"/>
        <source>Delete original</source>
        <translation>Eliminar o orixinal</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="92"/>
        <source>&amp;Convert</source>
        <translation>&amp;Converter</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="106"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="106"/>
        <source>Open a file</source>
        <translation>Abrir un ficheiro</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="110"/>
        <source>Convert</source>
        <translation>Converter</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="110"/>
        <source>Convert files</source>
        <translation>Converter ficheiros</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="114"/>
        <source>Quit</source>
        <translation>Saír</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="118"/>
        <source>Edit Presets</source>
        <translation>Editar as predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="122"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="122"/>
        <source>Import presets</source>
        <translation>Importar predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="126"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="126"/>
        <source>Export presets</source>
        <translation>Exportar predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="130"/>
        <source>Reset</source>
        <translation>Restabelecer</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="130"/>
        <source>Reset presets</source>
        <translation>Restabelecer as predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="62"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="142"/>
        <source>Clear form</source>
        <translation>Limpar o formulario</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="146"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="170"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="175"/>
        <source>File</source>
        <translation>Ficheiro</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="176"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="177"/>
        <source>Presets</source>
        <translation>Predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="178"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>All Files</source>
        <translation type="obsolete">Todos os ficheiros</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>Audio/Video Files</source>
        <translation type="obsolete">Ficheiros de son/vídeo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Image Files</source>
        <translation type="obsolete">Ficheiros de imaxe</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Document Files</source>
        <translation type="obsolete">Ficheiros de documentos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="298"/>
        <source>Choose File</source>
        <translation>Escoller o ficheiro</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="337"/>
        <source>Choose output destination</source>
        <translation>Escoller o destino da saída</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="375"/>
        <source>You must choose an output folder!</source>
        <translation>Ten que escoller un cartafol de saída!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="379"/>
        <source>Output folder does not exists!</source>
        <translation>O cartafol de saída non existe!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="385"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="444"/>
        <source>Convert among several file types to other extensions</source>
        <translation type="obsolete">Converter certos tipos de ficheiros a outros formatos</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="251"/>
        <source>Missing dependencies:</source>
        <translation>Non se atoparon as dependencias:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="60"/>
        <source>Add</source>
        <translation>Engadir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="61"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="142"/>
        <source>Clear All</source>
        <translation>Limpar todo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="372"/>
        <source>You must add at least one file to convert!</source>
        <translation>Ten que engadir, polo menos, un ficheiro para converter!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="89"/>
        <source>Save each file in the same
folder as input file</source>
        <translation>Gardar cada ficheiro no mesmo
cartafol que o orixinal</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="134"/>
        <source>Synchronize</source>
        <translation>Sincronizar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="134"/>
        <source>Synchronize presets</source>
        <translation>Sincronizar as predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="138"/>
        <source>Remove old</source>
        <translation>Retirar as antigas</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="138"/>
        <source>Remove old presets</source>
        <translation>Retirar as predefinicións antigas</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="165"/>
        <source>documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="427"/>
        <source>Convert among several file types to other formats</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="35"/>
        <source>Save files</source>
        <translation>Gardar os ficheiros</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="36"/>
        <source>Existing files:</source>
        <translation>Ficheiros existentes:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="37"/>
        <source>Add &apos;~&apos; prefix</source>
        <translation>Engadir o prefixo «~»</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="38"/>
        <source>Overwrite</source>
        <translation>Sobrescribir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="42"/>
        <source>Default output destination:</source>
        <translation>Destino de saída predeterminado:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="48"/>
        <source>Name files</source>
        <translation>Nomear os ficheiros</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="49"/>
        <source>Prefix:</source>
        <translation>Prefixo:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="50"/>
        <source>Suffix:</source>
        <translation>Sufixo:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="73"/>
        <source>FFmpeg</source>
        <translation type="obsolete">FFmpeg</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="69"/>
        <source>Default command:</source>
        <translation>Orde predeterminada:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="76"/>
        <source>Use:</source>
        <translation type="obsolete">Usar:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="78"/>
        <source>avconv</source>
        <translation type="obsolete">avconv</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="136"/>
        <source>General</source>
        <translation>Xeral</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="137"/>
        <source>Audio/Video</source>
        <translation>Son/Vídeo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="156"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="207"/>
        <source>Choose default output destination</source>
        <translation>Escolla o destino de saída predeterminado</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="72"/>
        <source>Video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="75"/>
        <source>Audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="117"/>
        <source>Extra formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="88"/>
        <source>Default video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="89"/>
        <source>Default audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="66"/>
        <source>Path to executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="101"/>
        <source>Default options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="138"/>
        <source>Images</source>
        <translation type="unfinished">Imaxes</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="139"/>
        <source>Documents</source>
        <translation type="unfinished">Documentos</translation>
    </message>
</context>
<context>
    <name>Progress</name>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="69"/>
        <source>In progress: </source>
        <translation>En progreso:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="71"/>
        <source>Total:</source>
        <translation type="obsolete">Total:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="73"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="75"/>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="106"/>
        <source>Conversion</source>
        <translation>Conversión</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="172"/>
        <source>Converted: %1/%2</source>
        <translation type="obsolete">Convertido: %1/%2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="196"/>
        <source>Cancel Conversion</source>
        <translation>Cancelar a conversión</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="196"/>
        <source>Are you sure you want to cancel conversion?</source>
        <translation>Confirma que quere cancelar a conversión?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="230"/>
        <source>In progress:</source>
        <translation>En progreso:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="159"/>
        <source>Report</source>
        <translation>Informe</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="164"/>
        <source>Close</source>
        <translation>Pechar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="160"/>
        <source>Converted: {0}/{1}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="72"/>
        <source>Shutdown after conversion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShowPresets</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="43"/>
        <source>Preset label</source>
        <translation>Etiqueta da predefinición</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="46"/>
        <source>Preset command line parameters</source>
        <translation>Parámetros da liña de ordes predefinidas</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="49"/>
        <source>Output file extension</source>
        <translation>Extensión do ficheiro de saída</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="52"/>
        <source>Add</source>
        <translation>Engadir</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="53"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="54"/>
        <source>Delete all</source>
        <translation>Eliminar todo</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="55"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="58"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="95"/>
        <source>Edit Presets</source>
        <translation>Editar as predeficións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="281"/>
        <source>Delete Preset</source>
        <translation>Eliminar a predefinición</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="184"/>
        <source>Are you sure that you want to delete the %1 preset?</source>
        <translation type="obsolete">Confirma que quere eliminar a predefinición %1?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="192"/>
        <source>Are you sure that you want to delete all presets?</source>
        <translation>Confirma que quere eliminar todas as predefinicións?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="249"/>
        <source>All current presets will be deleted.
Are you sure that you want to continue?</source>
        <translation>Todas as predefinicións van seren eliminadas.
Confirma que quere continuar?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="281"/>
        <source>Are you sure that you want to restore the default presets?</source>
        <translation>Confirma que quere restaurar as predefinicións predeterminadas?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="257"/>
        <source>Succesful import!</source>
        <translation type="obsolete">Importación correcta!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="259"/>
        <source>Import failed!</source>
        <translation>A importación fracasou!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="56"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="301"/>
        <source>Presets Synchronization</source>
        <translation>Sincronización de predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="301"/>
        <source>Current presets and default presets will be merged. Are you sure that you want to continue?</source>
        <translation>Todas as predefinicións actuais van seren mesturadas. Confirma que quere continuar?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="350"/>
        <source>Remove old presets</source>
        <translation>Retirar as predefinicións antigas</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="341"/>
        <source>All presets with an __OLD prefix will be deleted. Are you sure that you want to continue?</source>
        <translation type="obsolete">Todas as predefinicións coa extensión __OLD van seren eliminadas. Confirma que quere continuar?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="178"/>
        <source>Are you sure that you want to delete the {0} preset?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="267"/>
        <source>Export presets</source>
        <translation type="unfinished">Exportar predefinicións</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="350"/>
        <source>All presets with an __OLD suffix will be deleted. Are you sure that you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="255"/>
        <source>Successful import!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Default presets restored successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="344"/>
        <source>Synchronization completed.
Your presets are up to date!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="365"/>
        <source>Old presets successfully removed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tab</name>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="186"/>
        <source>More</source>
        <translation>Más</translation>
    </message>
</context>
</TS>
